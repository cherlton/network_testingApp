import { useEffect, useState } from "react";
import axios from "axios";

export default function SpeedTestDashboard() {
  const [speedData, setSpeedData] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [error, setError] = useState(null); // State to handle errors

  const BASE_URL = "http://127.0.0.1:5000"; // Ensure this matches your backend

  // Run Speed Test
  const runSpeedTest = async () => {
    console.log("🚀 Starting speed test...");
    setLoading(true);
    setError(null); // Reset error before new request

    try {
      const response = await axios.get(`${BASE_URL}/speedtest`);
      setSpeedData(response.data);

      console.log("✅ Speed test successful!");
      console.table(response.data);

      // Refresh history after new speed test
      fetchHistory();
    } catch (error) {
      console.error("❌ Error running speed test:", error);
      setError("Failed to run speed test. Please try again.");
    }

    setLoading(false);
    console.log("⏹️ Speed test completed.");
  };

  // Fetch Speed Test History
  const fetchHistory = async () => {
    console.log("📜 Fetching speed test history...");
    setError(null); // Reset error

    try {
      const response = await axios.get(`${BASE_URL}/history`);
      setHistory(response.data);
      console.log("📊 History loaded:", response.data);
    } catch (error) {
      console.error("❌ Error fetching history:", error);
      setError("Failed to load history. Please try again.");
    }
  };

  // Toggle History View
  const toggleHistory = () => {
    if (!showHistory) {
      fetchHistory(); // Load history only when showing it
    }
    setShowHistory(!showHistory);
  };

  // Fetch history on component mount
  useEffect(() => {
    fetchHistory();
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6 flex flex-col items-center">
      <h1 className="text-3xl font-bold mb-6">🚀 Network Speed Test Dashboard</h1>

      {/* Error Message */}
      {error && <p className="text-red-500 mb-4">{error}</p>}

      {/* Run Speed Test Button */}
      <button
        className="bg-blue-600 px-6 py-3 rounded-lg mb-6 hover:bg-blue-500 disabled:bg-gray-700"
        onClick={runSpeedTest}
        disabled={loading}
      >
        {loading ? "Testing..." : "Run Speed Test"}
      </button>

      {/* Display Latest Test Result */}
      {speedData && (
        <div className="bg-gray-800 p-4 rounded-lg w-96 mb-6 text-center">
          <h2 className="text-xl font-semibold">📈 Latest Test Result</h2>
          <p>📍 Ping: {speedData.ping} ms</p>
          <p>⬇️ Download: {speedData.download_speed.toFixed(2)} Mbps</p>
          <p>⬆️ Upload: {speedData.upload_speed.toFixed(2)} Mbps</p>
          <p className="text-sm text-gray-400">{speedData.timestamp}</p>
        </div>
      )}

      {/* Toggle Show/Hide History Button */}
      <button
        className="bg-green-600 px-6 py-3 rounded-lg mb-4 hover:bg-green-500"
        onClick={toggleHistory}
      >
        {showHistory ? "Hide History" : "Show History"}
      </button>

      {/* Speed Test History Table */}
      {showHistory && history.length > 0 && (
        <div className="bg-gray-800 p-4 rounded-lg w-full max-w-lg overflow-auto">
          <h2 className="text-2xl font-semibold mb-4 text-center">📜 Speed Test History</h2>
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-gray-700">
                <th className="p-2">📍 Ping (ms)</th>
                <th className="p-2">⬇️ Download (Mbps)</th>
                <th className="p-2">⬆️ Upload (Mbps)</th>
                <th className="p-2">🕒 Timestamp</th>
              </tr>
            </thead>
            <tbody>
              {history.map((entry, index) => (
                <tr key={index} className="border-t border-gray-700">
                  <td className="p-2">{entry.ping}</td>
                  <td className="p-2">{entry.download_speed.toFixed(2)}</td>
                  <td className="p-2">{entry.upload_speed.toFixed(2)}</td>
                  <td className="p-2 text-sm text-gray-400">{entry.timestamp}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showHistory && history.length === 0 && (
        <p className="text-gray-400">No history available.</p>
      )}
    </div>
  );
}
